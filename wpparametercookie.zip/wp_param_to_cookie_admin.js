document.addEventListener('DOMContentLoaded', function () {
    // Make the wp_param_to_cookie_data table sortable
    sorttable.makeSortable(document.getElementById('wp_param_to_cookie_data_table'));
});
